﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using RaceDayModel.Models;
using System;

namespace RaceDayData.Data
{
    
}

﻿namespace RaceDayModel.Models
{
    public class Users
    {
        public string UserID { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
    }

    public class Venue
    {
        public string VenueID { get; set; } = string.Empty;
        public string VenueName { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
        public string Province { get; set; } = string.Empty;
    }
    public class Events
    {
        public string EventID { get; set; } = string.Empty;
        public string OrganiserID { get; set; } = string.Empty;
        public string VenueID { get; set; } = string.Empty;
        public string EventName { get; set; } = string.Empty;
        public string EventType { get; set; } = string.Empty;
        public DateOnly EventDate { get; set; }
    }

    public class Login
    {
        public string Email { set; get; } = string.Empty;
        public string Password { set; get; } = string.Empty;
    }
}

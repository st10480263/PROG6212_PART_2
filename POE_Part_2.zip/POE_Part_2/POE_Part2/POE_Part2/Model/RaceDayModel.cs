﻿namespace RaceDayModel.Models
{
    public class Users
    {
        public string UserID { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
    }

    public class Login
    {
        public string Email { set; get; } = string.Empty;
        public string Password { set; get; } = string.Empty;
    }
}

﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using RaceDayData.Data;
using RaceDayModel.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace RaceDayApp.Controllers;

[ApiController]
public class RaceDayController : ControllerBase
{
    private readonly RaceDayDataContext _context;
    private const string SecretKey = "RaceDaySuperSecretKeyThatIsAtLeast32CharactersLong!";

    public RaceDayController(RaceDayDataContext context)
    {
        _context = context;
    }

    // ==========================================
    // 1. AUTHENTICATION ENDPOINTS
    // ==========================================

    [HttpPost("api/auth/register")]
    public IActionResult Register([FromBody] Users newUser)
    {
        if (_context.Users.Any(u => u.Email == newUser.Email))
            return Conflict("Email already registered.");

        _context.Users.Add(newUser);
        _context.SaveChanges();

        var token = CreateJwtToken(newUser);
        return StatusCode(201, new
        {
            message = "User registered successfully",
            token,
            user = newUser
        });
    }

    [HttpPost("api/auth/login")]
    public IActionResult Login([FromBody] LoginRequest request)
    {
        var user = _context.Users.FirstOrDefault(u => u.Email == request.Email && u.Password == request.Password);
        if (user == null)
            return Unauthorized("Invalid email or password.");

        var token = CreateJwtToken(user);
        return Ok(new { token, role = user.Role });
    }
    // ==========================================
    // 2. USER PROFILE ENDPOINTS
    // ==========================================

    [Authorize]
    [HttpGet("api/users/profile")]

    
    public IActionResult GetProfile()
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var user = _context.Users.Find(userId);
        if (user == null)
            return NotFound("User profile not found.");

        return Ok(user);
    }

    [Authorize]
    [HttpPut("api/users/profile")]
    public IActionResult UpdateProfile([FromBody] UpdateProfileRequest request)
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var user = _context.Users.Find(userId);
        if (user == null)
            return NotFound("User profile not found.");

        user.PhoneNumber = request.Phone;
        _context.SaveChanges();

        return Ok(user);
    }

    [HttpGet("api/events")]
    public IActionResult GetEvents([FromQuery] string? eventType, [FromQuery] DateOnly? date)
    {
        var query = _context.Events.AsQueryable();

        if (!string.IsNullOrWhiteSpace(eventType))
            query = query.Where(e => e.EventType == eventType);

        if (date.HasValue)
            query = query.Where(e => e.EventDate == date.Value);

        return Ok(query.ToList());
    }
    private string CreateJwtToken(Users user)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(SecretKey));
        var token = new JwtSecurityToken(
            claims: new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserID),
                new Claim(ClaimTypes.Role, user.Role),
                new Claim(ClaimTypes.Email, user.Email)
            },
            expires: DateTime.UtcNow.AddHours(4),
            signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256)
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
}
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayApp.Controllers;
using RaceDayData.Data;
using RaceDayModel.Models;
using System.Security.Claims;
using Xunit;

namespace RaceDayApp.Tests;

public class RaceDayControllersTests
{
    private RaceDayDataContext CreateInMemoryDbContext()
    {
        var options = new DbContextOptionsBuilder<RaceDayDataContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;

        return new RaceDayDataContext(options);
    }

    private void SetControllerUser(ControllerBase controller, string userId, string role)
    {
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, userId),
            new Claim(ClaimTypes.Role, role)
        };

        var identity = new ClaimsIdentity(claims, "TestAuth");
        var claimsPrincipal = new ClaimsPrincipal(identity);

        controller.ControllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext { User = claimsPrincipal }
        };
    }

    // ==========================================
    // 1. AUTHENTICATION TESTS
    // ==========================================

    [Fact]
    public void Login_ValidCredentials_ReturnsOkWithTokenAndRole()
    {
        // Arrange
        using var context = CreateInMemoryDbContext();
        context.Users.Add(new Users
        {
            UserID = "U001",
            Email = "runner@example.com",
            Password = "SecurePassword123",
            FullName = "Test Runner",
            Role = "Participant",
            PhoneNumber = "0821234567"
        });
        context.SaveChanges();

        var controller = new RaceDayController(context);
        var request = new Login { Email = "runner@example.com", Password = "SecurePassword123" };

        // Act
        var result = controller.Login(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        dynamic responseData = okResult.Value!;
        Assert.NotNull(responseData);
        Assert.Equal("Participant", (string)responseData.role);
    }

    [Fact]
    public void Login_InvalidPassword_ReturnsUnauthorized()
    {
        // Arrange
        using var context = CreateInMemoryDbContext();
        context.Users.Add(new Users
        {
            UserID = "U002",
            Email = "runner@example.com",
            Password = "CorrectPassword",
            Role = "Participant"
        });
        context.SaveChanges();

        var controller = new RaceDayController(context);
        var request = new Login { Email = "runner@example.com", Password = "WrongPassword" };

        // Act
        var result = controller.Login(request);

        // Assert
        Assert.IsType<UnauthorizedObjectResult>(result);
    }

    // ==========================================
    // 2. EVENT FILTERING TESTS
    // ==========================================

    [Fact]
    public void GetEvents_FilteredByEventType_ReturnsOnlyMatchingEvents()
    {
        // Arrange
        using var context = CreateInMemoryDbContext();
        context.Events.AddRange(
            new Events { EventID = "EVT-1", EventName = "Sprint 1", EventType = "Running", EventDate = new DateOnly(2026, 11, 1) },
            new Events { EventID = "EVT-2", EventName = "Ride 1", EventType = "Cycling", EventDate = new DateOnly(2026, 11, 2) },
            new Events { EventID = "EVT-3", EventName = "Sprint 2", EventType = "Running", EventDate = new DateOnly(2026, 11, 3) }
        );
        context.SaveChanges();

        var controller = new RaceDayController(context);

        // Act
        var result = controller.GetEvents("Running", null);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var eventList = Assert.IsAssignableFrom<List<Events>>(okResult.Value);
        Assert.Equal(2, eventList.Count);
        Assert.All(eventList, e => Assert.Equal("Running", e.EventType));
    }

    // ==========================================
    // 3. ENROLMENT TESTS
    // ==========================================

    [Fact]
    public void Enrol_NewCategory_Returns201Created()
    {
        // Arrange
        using var context = CreateInMemoryDbContext();
        var controller = new RaceDayController(context);
        SetControllerUser(controller, "PARTICIPANT-01", "Participant");

        var request = new EnrolmentRequest
        {
            EventID = "EVT-100",
            CategoryID = "CAT-10KM"
        };

        // Act
        var result = controller.Enrol(request);

        // Assert
        var createdResult = Assert.IsType<ObjectResult>(result);
        Assert.Equal(StatusCodes.Status201Created, createdResult.StatusCode);

        var enrolment = Assert.IsType<Enrolments>(createdResult.Value);
        Assert.Equal("PARTICIPANT-01", enrolment.ParticipantID);
        Assert.Equal("CAT-10KM", enrolment.CategoryID);
    }

    [Fact]
    public void Enrol_DuplicateCategory_Returns409Conflict()
    {
        // Arrange
        using var context = CreateInMemoryDbContext();
        context.Enrolments.Add(new Enrolments
        {
            EnrolmentID = "ENR-001",
            ParticipantID = "PARTICIPANT-01",
            CategoryID = "CAT-10KM",
            RegistrationDate = new DateOnly(2026, 10, 1)
        });
        context.SaveChanges();

        var controller = new RaceDayController(context);
        SetControllerUser(controller, "PARTICIPANT-01", "Participant");

        var request = new EnrolmentRequest
        {
            EventID = "EVT-100",
            CategoryID = "CAT-10KM"
        };

        // Act
        var result = controller.Enrol(request);

        // Assert
        var conflictResult = Assert.IsType<ConflictObjectResult>(result);
        Assert.Equal("Already enrolled in this category.", conflictResult.Value);
    }

    // ==========================================
    // 4. LEADERBOARD (CHAIN TRAVERSAL) TESTS
    // ==========================================

    [Fact]
    public void GetLeaderboard_TraversesCategoriesAndEnrolments_ReturnsSortedResults()
    {
        // Arrange
        using var context = CreateInMemoryDbContext();
        var targetEventId = "EVT-KYALAMI";

        // Category tied to Event
        context.Categories.Add(new Categories
        {
            CategoryID = "CAT-PRO",
            EventID = targetEventId,
            CategoryName = "Pro 10k",
            Distance = "10km",
            Country = "ZA"
        });

        // Enrolments tied to Category
        context.Enrolments.AddRange(
            new Enrolments { EnrolmentID = "ENR-A", CategoryID = "CAT-PRO", ParticipantID = "P1" },
            new Enrolments { EnrolmentID = "ENR-B", CategoryID = "CAT-PRO", ParticipantID = "P2" }
        );

        // Results tied to Enrolment
        context.Results.AddRange(
            new RaceDayModel.Models.Results
            {
                ResultsID = "RES-01",
                EnrolmentID = "ENR-A",
                Position = "2",
                FinishTime = new TimeOnly(1, 15, 30),
                Status = "Finished"
            },
            new RaceDayModel.Models.Results
            {
                ResultsID = "RES-02",
                EnrolmentID = "ENR-B",
                Position = "1",
                FinishTime = new TimeOnly(1, 10, 15),
                Status = "Finished"
            }
        );
        context.SaveChanges();

        var controller = new RaceDayController(context);

        // Act
        var result = controller.GetLeaderboard(targetEventId);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var leaderboard = Assert.IsAssignableFrom<List<RaceDayModel.Models.Results>>(okResult.Value);

        Assert.Equal(2, leaderboard.Count);
        Assert.Equal("1", leaderboard[0].Position);
        Assert.Equal("2", leaderboard[1].Position);
    }

    // ==========================================
    // 5. USER PROFILE TESTS
    // ==========================================

    [Fact]
    public void UpdateProfile_ValidUser_UpdatesPhoneNumberSuccessfully()
    {
        // Arrange
        using var context = CreateInMemoryDbContext();
        context.Users.Add(new Users
        {
            UserID = "U-PROFILE-TEST",
            FullName = "Tebogo M",
            Email = "tebogo@example.com",
            PhoneNumber = "0111111111"
        });
        context.SaveChanges();

        var controller = new RaceDayController(context);
        SetControllerUser(controller, "U-PROFILE-TEST", "Participant");

        var updateRequest = new UpdateProfileRequest
        {
            Phone = "0829998888",
            EmergencyContact = "0830001111"
        };

        // Act
        var result = controller.UpdateProfile(updateRequest);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var updatedUser = Assert.IsType<Users>(okResult.Value);
        Assert.Equal("0829998888", updatedUser.PhoneNumber);

        // Verify committed to in-memory database
        var dbUser = context.Users.Find("U-PROFILE-TEST");
        Assert.Equal("0829998888", dbUser?.PhoneNumber);
    }
}